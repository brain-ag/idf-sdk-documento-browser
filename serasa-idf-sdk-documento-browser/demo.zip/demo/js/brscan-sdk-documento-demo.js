function iniciaDocumento() {
  let doc = new window.BrScanSDKDocumento.Documento({
    chave: "1325927C99BF0EEA791F96CECE5D1D5B8BAC859D16CAABE4",
  });
  doc.preloadModelos(); // Recomendado colocar essa linha de início
  // Tamanho máximo do arquivo em MBs e texto do botão de envio (tela de envio manual de documento 'desktop')
  // doc.tamanhoArquivos = 5;
  // doc.enviarTxt = "Fazer upload";

  // Habilita Captura de Documentos em Desktop
  // doc.capturaEmDesktop = true;
  // Habilita captura manual quando necessário
  // doc.habilitaCapturaManual();
  // Habilita captura manual a partir de uma quantidade de tentativas incorretas
  // doc.qntTentativasCapManual = 0
  // Quantidade de tentativas que o usuário deve fazer para que o componente encerre
  // doc.limiteNumeroTentativasErro = 0

  // Define o timeout para sair da captura automática para manual
  // doc.timeoutCaptura = 2000;

  // Modifica os documentos aceitos
  // doc.documentosAceitos = ['rg', 'cnh', 'dni', 'cin', 'rne', 'rnm', 'outros', 'cnhdig', 'outrosdig'];

  // Mostra a versão atual do documento
  console.log(doc.versaoDocumento);

  // Inicia Wizard
  // doc.wizzard = false;

  // Caso queira trocar a cor dos botões e a fonte do componente, aqui está o exemplo:
  // document.documentElement.style.setProperty('--cor-primary', '#123');
  // document.documentElement.style.setProperty('--font-family', 'Inter');

  // Imagens que são possíveis serem alteradas no componente:
  // doc.imgDicasRetirarPlastico = '';
  // doc.imgDicasFreteEVerso = '';
  // doc.imgDicasEvitarReflexo = '';
  // doc.imgDicasBoaLeitura = '';
  // doc.imgLoading = '';
  // doc.imgErrorDocumento = '';
  // doc.imgTelaModal = '';
  // doc.imgFecharIcone = '';

  // Customização do frame de instrução do upload de documentos físicos:

  // Imagens:
  // doc.imgCameraIcon = '';
  // doc.imgArquivoPng = '';
  // doc.imgEnvieDoisArquivos = '';
  // doc.imgDicasDesktopFreteEVerso = '';

  // Cores:
  // doc.corBotaoTelaDicasDesktop = '';
  // doc.corBackgroundTelaDicasDesktop = '';

  // Textos:
  // doc.nomenclaturasObject.tituloCapturaTelaDicas = " ";
  // doc.nomenclaturasObject.subtituloCapturaTelaDicas = " ";
  // doc.nomenclaturasObject.capturaTelaDicasTexto1 = " ";
  // doc.nomenclaturasObject.capturaTelaDicasTexto2 = " "; 
  // doc.nomenclaturasObject.capturaTelaDicasTexto3 = " ";
  // doc.nomenclaturasObject.capturaTelaDicasTexto4 = " ";
  // doc.nomenclaturasObject.capturaTelaDicasTextoBotao = " ";
  // doc.nomenclaturasObject.selecaoDocTitulo = " ";

  doc
    .iniciaCaptura(document.getElementById('documento'))
    .then(documentos => {
      console.log(documentos);
      let imA = document.getElementById('imgA');
      imA.src = documentos.image[0];

      let imB = document.getElementById('imgB');
      imB.src = documentos.image[1];

      doc.finalizaJornadaSDK((jornada => {
        console.log(jornada.desc)
        console.log(jornada.id)
        console.log(jornada.protocolo_a)
        console.log(jornada.protocolo_b)
      }))

      doc.finalizaJornadaSDK((jornada => {
        if (jornada != 'loading') {
          console.log("Retorno completo da Jornada:", jornada);
        }
        if (jornada.id != undefined)
          console.log("ID retornado da Jornada:", jornada.id);
        if (jornada.protocolo_a != undefined)
          console.log("protocolo do documento lado A (se houver):", jornada.protocolo_a);
        if (jornada.protocolo_b != undefined)
          console.log("protocolo do documento lado B (se houver):", jornada.protocolo_b);
      }))
    })
    .catch(err => {
      console.log(err);
      console.log(err.id, err.desc);
    });
}
document.addEventListener('DOMContentLoaded', function (event) {
  iniciaDocumento();
});